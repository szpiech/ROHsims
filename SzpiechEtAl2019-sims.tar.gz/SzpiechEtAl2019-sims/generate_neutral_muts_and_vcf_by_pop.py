#!/usr/local/bin/python3

from sys import argv
import msprime, pyslim, gzip
import numpy as np 

script, infile = argv
outfilep1 = infile + ".p1.vcf.gz"
outfilep2 = infile + ".p2.vcf.gz"
outfilep3 = infile + ".p3.vcf.gz"

ts = pyslim.load(infile)

recap = ts.recapitate(recombination_rate=1e-8, Ne=7310, random_seed=np.random.randint(1,100000000))

mutated = msprime.mutate(recap, rate=2.124e-8, random_seed=np.random.randint(1,100000000), keep=True)


p1subsample = np.random.choice(np.unique(np.floor(mutated.samples(1)/2)), size=500, replace=False) 
p1subsample2 = 2*p1subsample
for s in p1subsample:
	p1subsample2=np.append(p1subsample2,2*s+1)

p1subsample2 = np.sort(p1subsample2.astype(np.int32))

p2subsample = np.random.choice(np.unique(np.floor(mutated.samples(2)/2)), size=500, replace=False) 
p2subsample2 = 2*p2subsample
for s in p2subsample:
	p2subsample2=np.append(p2subsample2,2*s+1)

p2subsample2 = np.sort(p2subsample2.astype(np.int32))

p3subsample = np.random.choice(np.unique(np.floor(mutated.samples(3)/2)), size=500, replace=False) 
p3subsample2 = 2*p3subsample
for s in p3subsample:
	p3subsample2=np.append(p3subsample2,2*s+1)

p3subsample2 = np.sort(p3subsample2.astype(np.int32))


ts_p1 = mutated.simplify(p1subsample2)
ts_p2 = mutated.simplify(p2subsample2)
ts_p3 = mutated.simplify(p3subsample2)


with gzip.open(outfilep1, "wt") as vcf_file:
	ts_p1.write_vcf(vcf_file,2)

with gzip.open(outfilep2, "wt") as vcf_file:
	ts_p2.write_vcf(vcf_file,2)

with gzip.open(outfilep3, "wt") as vcf_file:
	ts_p3.write_vcf(vcf_file,2)

